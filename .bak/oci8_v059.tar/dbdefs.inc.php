<?php
/**
 * Oracle Database Class.
 * Default Login data and configuration options.
 *
 * @author Sascha 'SieGeL' Pfalz <php@saschapfalz.de>
 * @package db_oci8
 * @version 0.59 (08-Jun-2005)
 * $Id: dbdefs.inc.php,v 1.3 2005/04/11 22:28:07 siegel Exp $
 */

/**
 * The TNS name of the target database to connect to. 
 * If running locally on the database server you may leave that string empty.
 */
define('OCIDB_HOST', '');

/**
 * The Database user used for connecting
 */
define('OCIDB_USER', 'SCOTT');
/**
 * The password used for connecting
 */
define('OCIDB_PASS', 'TIGER');

/**
 * Enter the name of your application here.
 * Used when printing out error messages and also used to register this name 
 * to Oracle when DB_REGISTER is set to 1
 * @see DB_REGISTER
 */ 
define('OCIAPPNAME', 'OCI8-CLASS');

/**
 * Set the following define to 0 if you do not want auto-register of APPNAME
 * @see APPNAME
 */
define('DB_REGISTER',1);

/**#@+ 
 * Define here what you are using as grouping character and decimal character
 * Germans usually use DECIMAL=, | GROUPING =. in opposite of english/american
 * which seems to be using DECIMAL=. | GROUPING=, and if you are using something
 * completly different, please drop me a short mail and tell me what you use, I
 * always love to learn :) 
 */
define('DB_NUM_DECIMAL'   ,'.');
define('DB_NUM_GROUPING'  ,',');
/**#@-*/ 

/** 
 * Modify default error handling mode if you wish (V0.57+).
 * Default is DBOF_SHOW_NO_ERRORS if you omit this parameter.
 */
define('DB_ERRORMODE', DBOF_SHOW_ALL_ERRORS);

/**
 * You may set a default prefetch value with this define (V0.58+).
 * This is a simple solution to have a higher prefetch value defined
 * as default for all your queries instead of calling setPrefetch()
 * everytime.
 */
define('DB_DEFAULT_PREFETCH', 10);
?>
